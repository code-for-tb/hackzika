NOAA-NWS now offers 'nowCOAST' web-mapping portal for coastal observations, forecasts, rainfall totals and warnings. 

Please browse for a service at: https://nowcoast.noaa.gov/help/#!section=map-service-list